function runNdgEdgeTest(  )

results = runtests('NdgEdge/UnitTest/NdgEdgeTest.m')
end


function runStdCellTest
%RUNSTDCELLTEST Summary of this function goes here
%   Detailed explanation goes here

results = runtests('NdgCell/UnitTest/StdCellTest.m')
end


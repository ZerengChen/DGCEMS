classdef enumStdCell < int8
    enumeration
        Point       (0)
        Line        (1)
        Tri         (2)
        Quad        (3)
        PrismTri    (4)
        PrismQuad   (5)
    end
end% classdef
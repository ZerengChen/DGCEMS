% ---------------------------- DEFINE THE FILE --------------------------- %  

ncid=netcdf.create('xxx\init_fphys.nc','CLOBBER');

%-----------------------------define dimension-----------------------------% 
% create dim in ncfile
K_d=netcdf.defDim(ncid,'K',Solver.meshUnion.K);
K2d_d=netcdf.defDim(ncid,'K2d',Solver.meshUnion.mesh2d.K);
cell_Np_d=netcdf.defDim(ncid,'cell_Np',Solver.meshUnion.cell.Np);
cell_Np2d_d=netcdf.defDim(ncid,'cell_Np2d',Solver.meshUnion.mesh2d.cell.Np);
Nfield_d=netcdf.defDim(ncid,'Nfield',16);
Nfield2d_d=netcdf.defDim(ncid,'Nfield2d',8);
two_d=netcdf.defDim(ncid,'two',2);
three_d=netcdf.defDim(ncid,'Three',3);%chenzereng

fphys2d_d=netcdf.defDim(ncid,'fphys2d_d',Solver.meshUnion.mesh2d.K*Solver.meshUnion.mesh2d.cell.Np * 8);
fphys_d=netcdf.defDim(ncid,'fphys_d',Solver.meshUnion.K*Solver.meshUnion.cell.Np * 16);
%zGrad_d=netcdf.defDim(ncid,'zGrad_d',Solver.meshUnion.K*Solver.meshUnion.cell.Np*2);
%---------------------------define new variables---------------------------%
% create variables in ncfile
fphys_temp=Solver.fphys{1}(:);
fphys2d_temp=Solver.fphys2d{1}(:);
%zGrad_temp=Solver.zGrad{1}(:);
fphys2d_v=netcdf.defVar(ncid,'fphys2d','double',fphys2d_d);
fphys_v=netcdf.defVar(ncid,'fphys','double',fphys_d);
%zGrad_v=netcdf.defVar(ncid,'zGrad','double',zGrad_d);
netcdf.endDef(ncid);
%--------------------------------------------------------------------------%
netcdf.putVar(ncid,fphys_v,fphys_temp);
netcdf.putVar(ncid,fphys2d_v,fphys2d_temp);
%netcdf.putVar(ncid,zGrad_v,zGrad_temp);
netcdf.close(ncid);















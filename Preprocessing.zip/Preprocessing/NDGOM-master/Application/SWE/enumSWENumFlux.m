classdef enumSWENumFlux < int8
    
    enumeration
        HLL     (1)
        HLLC    (2)
        ROE     (3)
        LF      (4)
    end
end


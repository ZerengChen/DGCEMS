classdef enumSWECoriolis < int8
    
    enumeration
        None        (0)
        Beta        (1)
        Latitude    (2)
    end
    
end


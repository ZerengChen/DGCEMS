classdef enumSWEFriction < int8
    
    enumeration
        None   (1)
        Linear (2)
        Quadric (4)
        Manning (3)
    end
    
end



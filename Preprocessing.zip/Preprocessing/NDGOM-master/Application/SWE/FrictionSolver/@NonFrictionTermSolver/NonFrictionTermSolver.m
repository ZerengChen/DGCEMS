classdef NonFrictionTermSolver < AbstractFrictionTermSolver
    
    methods
        function evaluateFrictionTermRHS( obj, physClass, fphys )
            % do nothing ...
        end
    end
    
end



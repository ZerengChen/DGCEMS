classdef enumSWELimiter < int8
    
    enumeration
        OnDepth     (1)
        OnElevation (2)
    end
    
end


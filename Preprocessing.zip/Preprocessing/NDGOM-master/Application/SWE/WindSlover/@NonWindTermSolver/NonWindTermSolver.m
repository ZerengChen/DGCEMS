classdef NonWindTermSolver < AbstractWindTermSolver
    
    methods
        function evaluateWindTermRHS( obj, physClass, fphys )
            % do nothing ...
        end
    end
    
end


classdef enumSWEVerticalEddyViscosity < int8
    
    enumeration
        Constant        (0)
        Parabolic    (1)
        GOTM        (2)
        None (3)
    end
    
end


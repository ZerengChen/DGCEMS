classdef enumSWEHorizontalEddyViscosity < int8
    
    enumeration
        Constant        (0)
        Smagorinsky    (1)
        None        (2)
    end
    
end
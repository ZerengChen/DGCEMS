function matUpdateExternalField( obj, tloc, fphys2d, fphys )
%do nothing here

end
function matEvaluateSourceTerm( obj, fphys )
% frhs = frhs + BottomTerm
obj.matEvaluateTopographySourceTerm( fphys );
% frhs = frhs + CoriolisTerm
obj.coriolisSolver.evaluateCoriolisTermRHS(obj, fphys);
end
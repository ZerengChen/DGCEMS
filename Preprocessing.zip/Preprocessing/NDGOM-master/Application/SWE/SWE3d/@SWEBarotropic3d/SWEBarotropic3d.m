classdef SWEBarotropic3d < SWEAbstract3d
    %SWEBAROTROPIC3D �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
        %> number of physical field
        Nfield2d = 8 %[H HU HV Z Zx Zy U_Euler2d V_Euler2d]
        %> num of 3d physical field
        Nfield = 16 % [ Hu, Hv, omega, H, miu, Z, eta, Zx, Zy U_Euler3d V_Euler3d hc rho T S hc1 ...]
        
        fieldName3d = {'hu','hv','omega', 'h','nv','z','eta','zx','zy','U_Euler3d', 'V_Euler3d','hc', 'rho','T','S','hc1'};
        %> number of variable field
        Nvar = 2
        %> index of variable in physical field
        varFieldIndex = [ 1, 2 ]
        %> number of variable field
        Nvar2d = 1
        %> index of variable in physical field
        varFieldIndex2d = 1
        
        fieldName2d = {'h','hU','hV'};
    end
    
    properties
        Limiter
    end
    
    properties
        %> the 2d field to be put in the output file
        outputFieldOrder2d =  1
        %> the 3d field to be put in the output file
        outputFieldOrder3d = [1 2 3]
    end
    
    methods
        function fphys = matImposeLimiter(obj, fphys)
            for i = 1:obj.Nvar
               fphys = obj.Limiter.matLimit( fphys, obj.varFieldIndex(i) );
            end
        end
    end
    
    methods( Hidden )
        [ E, G, H ] = matEvaluateFlux( obj, mesh, fphys );
        
    end
    
    methods ( Hidden, Access = public ) % public function, not allow to inherit
        
        [ fluxM ] = matEvaluateSurfFlux( obj, mesh, nx, ny, nz, fm )
        
        %> evaluate boundary numerical flux
        function [ fluxS ] = matEvaluateSurfNumFlux( obj, mesh, nx, ny, fm, fp, edge )
            [ fluxS ] = obj.numfluxSolver.evaluate( obj.hcrit, obj.gra, nx, ny, fm, fp, mesh, edge );
        end% func
    end
    
    methods ( Access = protected )
        
        matEvaluateRK45( obj );
        
        function matEvaluatePostFunc(obj, fphys2d)
            obj.matUpdateWetDryState(fphys2d);
        end
        
    end
    
end


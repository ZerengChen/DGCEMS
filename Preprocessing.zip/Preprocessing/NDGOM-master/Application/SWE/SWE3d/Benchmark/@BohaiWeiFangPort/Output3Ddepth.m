
clear,clc;
SMSfile = 'D:\DGMprogram\RanGuoquan\NDGOM-master\Application\SWE\SWE3d\Benchmark\@BohaiLiaoDongBay\dry.14';
fid2 = fopen(SMSfile,'r');
if( fid2 < 0 )
    msgID = [mfilename, ':inputFileNameError'];
    msgtext = ['The input file name: ', filename, ' is incorrect'];
    ME = MException(msgID, msgtext);
    throw(ME);
end
% READ FIRST LINE
fgetl(fid2);
% READ NODES AND ELEMENTS
temp = fscanf(fid2,'%d',2); Nv = temp(2); Ne = temp(1);
data = fscanf(fid2,'%d %f %f %f\n',[4,Nv]);%读完节点编号
data2 = fscanf(fid2,'%d %d %d %d %d\n',[5,Ne]);%读完网格编号

fclose(fid2);
% 创建一个示例的水深矩阵
x = data(:,2);
y = data(:,3);
depth = -data(:,4);

% 绘制水深图
figure;
surf(x, y, depth);
title('三维水深图');
xlabel('X轴');
ylabel('Y轴');
zlabel('水深');

% 添加颜色映射
colormap(jet);

% 可以根据需要旋转和调整视角
%view(45, 30);
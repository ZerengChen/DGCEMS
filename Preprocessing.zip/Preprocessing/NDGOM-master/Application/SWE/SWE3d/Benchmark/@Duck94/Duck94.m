classdef Duck94 < SWEBarotropic3d
    %WINDDRIVENFLOW �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties ( Constant )

        startTime = 0;       
        hcrit = 0.1;        
        SMSFile = [pwd,'\Application\SWE\SWE3d\Benchmark\@Duck94\fort.14'];
        %tidalFile = [pwd,'\Application\SWE\SWE3d\Benchmark\@BohaiLiaoDongBay\Tidal.xlsx'];
        
    end
    
    properties
        finalTime = 7200;
        
        tideinterval = 600;
        
%         OBEdgeIndex
        
%         Tide
    end
    
    methods
        function obj = Duck94( N, Nz, Mz )
            % setup mesh domain
            [ obj.mesh2d, obj.mesh3d ] = makeChannelMesh( obj, N, Nz, Mz );
            obj.outputFieldOrder2d = [ 1 2 3 ];
            obj.outputFieldOrder3d = [ 1 2 4 6];
            % allocate boundary field with mesh obj
            obj.initPhysFromOptions( obj.mesh2d, obj.mesh3d );
            obj.Cf{1} = 0.005*ones(size(obj.mesh2d(1).x));
%             obj.ReadTideElevation;
            obj.SurfBoundNewmannDate(:,:,1) = 0.0/1000 * ones(size(obj.SurfBoundNewmannDate(:,:,1)));%0.1
        end
        
        %matEvaluateSSPRK22(obj);
        
        AnalysisResult2d( obj );
        AnalysisResult3d( obj );
        plot_uv2d( obj );
        plot_h2d( obj );
        PostProcess_level( obj );
        PostProcess_speed( obj );
        PostProcess_direction( obj );
    end
    
    methods ( Access = protected )
        
%         ReadTideElevation( obj );
        
        %> set initial function
        function [fphys2d, fphys] = setInitialField( obj )
            fphys2d = cell( obj.Nmesh, 1 );
            fphys = cell( obj.Nmesh, 1 );
            for m = 1 : obj.Nmesh
                mesh2d = obj.mesh2d(m);
                mesh3d = obj.mesh3d(m);
                fphys2d{m} = zeros( mesh2d.cell.Np, mesh2d.K, obj.Nfield2d );
                fphys{m} = zeros( mesh3d.cell.Np, mesh3d.K, obj.Nfield );
                % bottom elevation
                fphys2d{m}(:, :, 4) = obj.mesh2d.z;
                %water depth
                fphys2d{m}(:,:,1) = -obj.mesh2d.z;
            end
            
        end
        
        function matUpdateExternalField( obj, time, fphys2d, fphys )
%             delta = obj.tideinterval;
%             for m1 = 1:obj.Nmesh
%                 %     mesh = obj.meshUnion( m1 );
%                 
%                 % time step
%                 s1 = floor( time/delta ) + 1;
%                 s2 = s1 + 1;
%                 alpha1 = ( delta * (s2 - 1) - time ) / delta;
%                 alpha2 = ( time - delta * (s1 - 1) ) / delta;
%                 
%                 ind = obj.OBEdgeIndex{m1};
%                 fnT = obj.Tide{m1}(:, :, s1) .* alpha1 + obj.Tide{m1}(:, :, s2) .* alpha2;
%                 obj.fext2d{m1}(:,ind,1) = max( fnT - obj.fext2d{m1}(:,ind,4), 0 );
%                 obj.fext3d{m1}(:,:,3) = obj.meshUnion.BoundaryEdge.matVerticalRepmatFacialValue(obj.fext2d{m1}(:,:,1));
%             end
            
           VCV = obj.meshUnion(1).cell.VCV;
           Nz = obj.meshUnion(1).Nz;
           Hu = VCV * fphys{1}(:,Nz:Nz:end,1);
           Hv = VCV * fphys{1}(:,Nz:Nz:end,2);
           H  = VCV * fphys{1}(:,Nz:Nz:end,4);
           obj.BotBoundNewmannDate(:,:,1) = obj.Cf{1} .* sqrt( (Hu./H).^2 + ...
               (Hv./H).^2 ) .* ( Hu./H ) * (-1);
           obj.BotBoundNewmannDate(:,:,2) = obj.Cf{1} .* sqrt( (Hu./H).^2 + ...
               (Hv./H).^2 ) .* ( Hv./H ) * (-1); 
            
        end
        
        function [ option ] = setOption( obj, option )
            ftime = 7200;
            outputIntervalNum = 600;
            option('startTime') = 0.0;
            option('finalTime') = ftime;
            option('outputIntervalType') = enumOutputInterval.DeltaTime;
            option('outputTimeInterval') = ftime/outputIntervalNum;
            option('outputCaseName') = mfilename;
            option('outputNcfileNum') = 1;
            option('temporalDiscreteType') = enumTemporalDiscrete.SSPRK22;
            option('VerticalEddyViscosityType') = enumSWEVerticalEddyViscosity.Constant;
            option('equationType') = enumDiscreteEquation.Strong;
            option('integralType') = enumDiscreteIntegral.QuadratureFree;
            option('outputType') = enumOutputFile.NetCDF;
            option('limiterType') = enumLimiter.None;
            option('ConstantVerticalEddyViscosityValue') = 0.01;
            option('HorizontalEddyViscosityType') = enumSWEHorizontalEddyViscosity.None;
            option('ConstantHorizontalEddyViscosityValue') = 0.1;
        end
        
    end
    
end

function [mesh2d, mesh3d] = makeChannelMesh( obj, N, Nz, Mz )

% bctype = [ ...
%     enumBoundaryCondition.SlipWall, ...
%     enumBoundaryCondition.SlipWall, ...
%     enumBoundaryCondition.ZeroGrad, ...
%     enumBoundaryCondition.ZeroGrad ];


mesh2d = makeSMSFileUMeshUnion2d( N, obj.SMSFile );

cell = StdPrismTri( N, Nz );
zs = zeros(mesh2d.Nv, 1); zb = zs - 1;
mesh3d = NdgExtendMesh3d( cell, mesh2d, zs, zb, Mz );
mesh3d.InnerEdge = NdgSideEdge3d( mesh3d, 1, Mz );
mesh3d.BottomEdge = NdgBottomInnerEdge3d( mesh3d, 1 );
mesh3d.BoundaryEdge = NdgHaloEdge3d( mesh3d, 1, Mz );
mesh3d.BottomBoundaryEdge = NdgBottomHaloEdge3d( mesh3d, 1 );
mesh3d.SurfaceBoundaryEdge = NdgSurfaceHaloEdge3d( mesh3d, 1 );
% [ mesh2d, mesh3d ] = ImposePeriodicBoundaryCondition3d(  mesh2d, mesh3d, 'West-East' );
% [ mesh2d, mesh3d ] = ImposePeriodicBoundaryCondition3d(  mesh2d, mesh3d, 'South-North' );
end


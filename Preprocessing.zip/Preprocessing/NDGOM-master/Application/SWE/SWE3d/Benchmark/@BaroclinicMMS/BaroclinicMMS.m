classdef BaroclinicMMS < SWEBarotropic3d
    %LOCKEXCHANGECASE �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties ( Constant )

        startTime = 0;       
        hcrit = 0.1;        
        SMSFile = [pwd,'\Application\SWE\SWE3d\Benchmark\@BaroclinicMMS\1250.14'];
        %tidalFile = [pwd,'\Application\SWE\SWE3d\Benchmark\@BohaiLiaoDongBay\Tidal.xlsx'];
        
    end
    
    properties
        finalTime = 7200;
        
        tideinterval = 600;
        
%         OBEdgeIndex
        
%         Tide
    end
    
    methods
        function obj = BaroclinicMMS( N, Nz, Mz )
            % setup mesh domain
            [ obj.mesh2d, obj.mesh3d ] = makeChannelMesh( obj, N, Nz, Mz );
            obj.outputFieldOrder2d = [ 1 2 3 ];
            obj.outputFieldOrder3d = [ 1 2 4 6];
            % allocate boundary field with mesh obj
            obj.initPhysFromOptions( obj.mesh2d, obj.mesh3d );
            obj.Cf{1} = 0.005*ones(size(obj.mesh2d(1).x));
%             obj.ReadTideElevation;
            obj.Nvar = 4;
            obj.SurfBoundNewmannDate(:,:,1) = 0.0/1000 * ones(size(obj.SurfBoundNewmannDate(:,:,1)));%0.1
        end
        
        %matEvaluateSSPRK22(obj);
        
%         AnalysisResult2d( obj );
%         AnalysisResult3d( obj );
%         plot_uv2d( obj );
%         plot_h2d( obj );
%         PostProcess_level( obj );
%         PostProcess_speed( obj );
%         PostProcess_direction( obj );
    end
    
    methods ( Access = protected )
        
%         ReadTideElevation( obj );
        
        %> set initial function
        function [fphys2d, fphys] = setInitialField( obj )
            fphys2d = cell( obj.Nmesh, 1 );
            fphys = cell( obj.Nmesh, 1 );
            for m = 1 : obj.Nmesh
                mesh2d = obj.mesh2d(m);
                mesh3d = obj.mesh3d(m);
                fphys2d{m} = zeros( mesh2d.cell.Np, mesh2d.K, obj.Nfield2d );
                fphys{m} = zeros( mesh3d.cell.Np, mesh3d.K, obj.Nfield );
%                 Index = all(mesh3d.x<= 32000);
%                 fphys{m}(:,Index,16) = 35;

                fphys{m}(:,:,16) = 35;%�ζȳ�35psu
                fphys{m}(:,:,15) = 15 + 15 .* sin(pi.*mesh3d.x / 15000).*sin(pi.*mesh3d.y/10000).*cos(mesh3d.z);%�¶ȳ�
                fphys{m}(:,:,14) = 1000 - 0.2 * (fphys{m}(:,:,15) - 5);%�ܶȳ�35psu
                fphys{m}(:,:,1) = 40*0.5.*sin(2*pi.*mesh3d.x / 15000).*cos(3.*mesh3d.z);%hu
                fphys{m}(:,:,2) = 40/3.*cos(pi.*mesh3d.y / 10000).*sin(0.5.*mesh3d.z);%hv
                fphys{m}(:,:,3) = -40*pi/3/15000.*cos(2*pi.*mesh3d.x / 15000).*(sin(3) + sin(3.*mesh3d.z))+80*pi/3/10000.*(-cos(0.5)+cos(0.5.*mesh3d.z)).*sin(pi.*mesh3d.y / 10000);%omg
                fphys2d{m}(:, :, 2) = 40/6*sin(3).*sin(2*pi.*mesh2d.x / 15000);%hu2d
                fphys2d{m}(:, :, 3) = -40*4/3*sin(0.25)*sin(0.25).*cos(pi.*mesh2d.y / 10000);%hv2d
                % bottom elevation
                fphys2d{m}(:, :, 4) = obj.mesh2d.z;
                %water depth
                fphys2d{m}(:,:,1) = -obj.mesh2d.z;
            end
            
        end
        
        function matUpdateExternalField( obj, time, fphys2d, fphys )
            
           VCV = obj.meshUnion(1).cell.VCV;
           Nz = obj.meshUnion(1).Nz;
           Hu = VCV * fphys{1}(:,Nz:Nz:end,1);
           Hv = VCV * fphys{1}(:,Nz:Nz:end,2);
           H  = VCV * fphys{1}(:,Nz:Nz:end,4);
           obj.BotBoundNewmannDate(:,:,1) = obj.Cf{1} .* sqrt( (Hu./H).^2 + ...
               (Hv./H).^2 ) .* ( Hu./H ) * (-1);
           obj.BotBoundNewmannDate(:,:,2) = obj.Cf{1} .* sqrt( (Hu./H).^2 + ...
               (Hv./H).^2 ) .* ( Hv./H ) * (-1); 
            
        end
        
        function [ option ] = setOption( obj, option )
            ftime = 7200;
            outputIntervalNum = 600;
            option('startTime') = 0.0;
            option('finalTime') = ftime;
            option('outputIntervalType') = enumOutputInterval.DeltaTime;
            option('outputTimeInterval') = ftime/outputIntervalNum;
            option('outputCaseName') = mfilename;
            option('outputNcfileNum') = 1;
            option('temporalDiscreteType') = enumTemporalDiscrete.SSPRK22;
            option('VerticalEddyViscosityType') = enumSWEVerticalEddyViscosity.Constant;
            option('equationType') = enumDiscreteEquation.Strong;
            option('integralType') = enumDiscreteIntegral.QuadratureFree;
            option('outputType') = enumOutputFile.NetCDF;
            option('limiterType') = enumLimiter.None;
            option('ConstantVerticalEddyViscosityValue') = 0.01;
            option('HorizontalEddyViscosityType') = enumSWEHorizontalEddyViscosity.None;
            option('ConstantHorizontalEddyViscosityValue') = 0.1;
        end
        
    end
    
end

function [mesh2d, mesh3d] = makeChannelMesh( obj, N, Nz, Mz )

% bctype = [ ...
%     enumBoundaryCondition.SlipWall, ...
%     enumBoundaryCondition.SlipWall, ...
%     enumBoundaryCondition.ZeroGrad, ...
%     enumBoundaryCondition.ZeroGrad ];


mesh2d = makeSMSFileUMeshUnion2d( N, obj.SMSFile );

cell = StdPrismTri( N, Nz );
zs = zeros(mesh2d.Nv, 1); zb = zs - 1;
mesh3d = NdgExtendMesh3d( cell, mesh2d, zs, zb, Mz );
mesh3d.InnerEdge = NdgSideEdge3d( mesh3d, 1, Mz );
mesh3d.BottomEdge = NdgBottomInnerEdge3d( mesh3d, 1 );
mesh3d.BoundaryEdge = NdgHaloEdge3d( mesh3d, 1, Mz );
mesh3d.BottomBoundaryEdge = NdgBottomHaloEdge3d( mesh3d, 1 );
mesh3d.SurfaceBoundaryEdge = NdgSurfaceHaloEdge3d( mesh3d, 1 );
% [ mesh2d, mesh3d ] = ImposePeriodicBoundaryCondition3d(  mesh2d, mesh3d, 'West-East' );
% [ mesh2d, mesh3d ] = ImposePeriodicBoundaryCondition3d(  mesh2d, mesh3d, 'South-North' );
end
classdef enumSWEWind < int8
    
    enumeration
        None   (1)
        UV     (2)
        Stress (3)
        %File  (4)
    end
    
end



classdef NonCoriolisTermSolver < AbstractCoriolisTermSolver
    
    methods
        function evaluateCoriolisTermRHS( obj, physClass, fphys )
            % do nothing ...
        end
    end
    
end


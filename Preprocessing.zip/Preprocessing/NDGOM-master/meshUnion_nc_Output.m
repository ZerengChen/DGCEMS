% ---------------------------- DEFINE THE FILE --------------------------- %  

ncid=netcdf.create('zzz\meshUnion.nc','CLOBBER');

%-----------------------------define dimension-----------------------------% 
% create dim in ncfile
K_d=netcdf.defDim(ncid,'K',Solver.meshUnion.K);
Nv_d=netcdf.defDim(ncid,'Nv',Solver.meshUnion.Nv);
Nlayer_d=netcdf.defDim(ncid,'Nlayer',Solver.meshUnion.Nz);
N_d=netcdf.defDim(ncid,'N',Solver.meshUnion.cell.N);
Nz_d=netcdf.defDim(ncid,'Nz',Solver.meshUnion.cell.Nz);%vertical stage
Ne_inner_d=netcdf.defDim(ncid,'Ne_inner',Solver.meshUnion.InnerEdge.Ne);
Ne_boundary_d=netcdf.defDim(ncid,'Ne_boundary',Solver.meshUnion.BoundaryEdge.Ne);
Ne_bottom_d=netcdf.defDim(ncid,'Ne_bottom',Solver.meshUnion.BottomEdge.Ne);
Ne_bottomboundary_d=netcdf.defDim(ncid,'Ne_bottomboundary',Solver.meshUnion.BottomBoundaryEdge.Ne);
Ne_surface_d=netcdf.defDim(ncid,'Ne_surface',Solver.meshUnion.SurfaceBoundaryEdge.Ne);
Np_d=netcdf.defDim(ncid,'Np',Solver.meshUnion.cell.Np);
one_d=netcdf.defDim(ncid,'One',1);
two_d=netcdf.defDim(ncid,'Two',2);
three_d=netcdf.defDim(ncid,'Three',3);
four_d=netcdf.defDim(ncid,'Four',4);
cell_Nv_d=netcdf.defDim(ncid,'cell_Nv',Solver.meshUnion.cell.Nv);
cell_Nface_d=netcdf.defDim(ncid,'cell_Nface',Solver.meshUnion.cell.Nface);
Nfp_d=netcdf.defDim(ncid,'Nfp',Solver.meshUnion.InnerEdge.Nfp);
NfpBottom_d=netcdf.defDim(ncid,'NfpBottom',Solver.meshUnion.BottomEdge.Nfp);
cell_Nq_d=netcdf.defDim(ncid,'cell_Nq',Solver.meshUnion.cell.Nq);
Nzadd1_d=netcdf.defDim(ncid,'Nzadd1',Solver.meshUnion.cell.Npz);%chenzeren

% create variables in ncfile2d
K2d_d=netcdf.defDim(ncid,'K2d',Solver.meshUnion.mesh2d.K);
Nv2d_d=netcdf.defDim(ncid,'Nv2d',Solver.meshUnion.mesh2d.Nv);
Ne_inner2d_d=netcdf.defDim(ncid,'Ne_inner2d',Solver.meshUnion.mesh2d.InnerEdge.Ne);
Ne_boundary2d_d=netcdf.defDim(ncid,'Ne_boundary2d',Solver.meshUnion.mesh2d.BoundaryEdge.Ne);
Np2d_d=netcdf.defDim(ncid,'cell_Np2d',Solver.meshUnion.mesh2d.cell.Np);
cell_Nv2d_d=netcdf.defDim(ncid,'cell_Nv2d',Solver.meshUnion.mesh2d.cell.Nv);
Nfp2d_d=netcdf.defDim(ncid,'InnerEdge_cell_Nfp2d',Solver.meshUnion.mesh2d.InnerEdge.Nfp);
cell_Nq2d_d=netcdf.defDim(ncid,'cell_Nq2d',Solver.meshUnion.mesh2d.cell.Nq);
icell_Nq_d=netcdf.defDim(ncid,'InnerEdge_cell_Nq2d',Solver.meshUnion.mesh2d.InnerEdge.cell.Nq);
%---------------------------define new variables---------------------------%
% create variables in ncfile

type_v=netcdf.defVar(ncid,'type','double',one_d);
K_v=netcdf.defVar(ncid,'K','NC_DOUBLE',one_d);
Nv_v=netcdf.defVar(ncid,'Nv','double',one_d);
Nlayer_v=netcdf.defVar(ncid,'Nlayer','double',one_d);
N_v=netcdf.defVar(ncid,'N','double',one_d);
Nz_v=netcdf.defVar(ncid,'Nz','double',one_d);

Ne_inner_v=netcdf.defVar(ncid,'Ne_inner','double',one_d);
Ne_boundary_v=netcdf.defVar(ncid,'Ne_boundary','double',one_d);
Ne_bottom_v=netcdf.defVar(ncid,'Ne_bottom','double',one_d);
Ne_bottomboundary_v=netcdf.defVar(ncid,'Ne_bottomboundary','double',one_d);
Ne_surface_v=netcdf.defVar(ncid,'Ne_surface','double',one_d);
Nfp_v=netcdf.defVar(ncid,'Nfp','double',one_d);
Np_v=netcdf.defVar(ncid,'Np','double',one_d);
NfpBottom_v=netcdf.defVar(ncid,'NfpBottom','double',one_d);

Nzadd1_v=netcdf.defVar(ncid,'Nzadd1','double',one_d);
EToV_v=netcdf.defVar(ncid,'EToV','double',[cell_Nv_d K_d]);
%EToR_v=netcdf.defVar(ncid,'EToR','NC_BYTE',[K_d one_d]);
vx_v=netcdf.defVar(ncid,'vx','double',[Nv_d, one_d]);
vy_v=netcdf.defVar(ncid,'vy','double',[Nv_d, one_d]);
vz_v=netcdf.defVar(ncid,'vz','double',[Nv_d, one_d]);
ind_v=netcdf.defVar(ncid,'ind','double',one_d);
%status_v=netcdf.defVar(ncid,'status','NC_BYTE',[one_d K_d]);
EToE_v=netcdf.defVar(ncid,'EToE','double',[cell_Nface_d K_d]);
EToF_v=netcdf.defVar(ncid,'EToF','double',[cell_Nface_d K_d]);
EToM_v=netcdf.defVar(ncid,'EToM','double',[cell_Nface_d K_d]);
EToL_v=netcdf.defVar(ncid,'EToL','double',[K_d one_d]);%chenzereng
x_v=netcdf.defVar(ncid,'x','double',[Np_d K_d]);
y_v=netcdf.defVar(ncid,'y','double',[Np_d K_d]);
z_v=netcdf.defVar(ncid,'z','double',[Np_d K_d]);
J_v=netcdf.defVar(ncid,'J','double',[Np_d K_d]);
Jz_v=netcdf.defVar(ncid,'Jz','double',[Np_d K_d]);
rx_v=netcdf.defVar(ncid,'rx','double',[Np_d K_d]);
ry_v=netcdf.defVar(ncid,'ry','double',[Np_d K_d]);
rz_v=netcdf.defVar(ncid,'rz','double',[Np_d K_d]);
sx_v=netcdf.defVar(ncid,'sx','double',[Np_d K_d]);
sy_v=netcdf.defVar(ncid,'sy','double',[Np_d K_d]);
sz_v=netcdf.defVar(ncid,'sz','double',[Np_d K_d]);
tx_v=netcdf.defVar(ncid,'tx','double',[Np_d K_d]);
ty_v=netcdf.defVar(ncid,'ty','double',[Np_d K_d]);
tz_v=netcdf.defVar(ncid,'tz','double',[Np_d K_d]);
LAV_v=netcdf.defVar(ncid,'LAV','double',[one_d K_d]);
%charLength_v=netcdf.defVar(ncid,'charLength','double',[one_d K_d]);
xc_v=netcdf.defVar(ncid,'xc','double',[one_d K_d]);
yc_v=netcdf.defVar(ncid,'yc','double',[one_d K_d]);
zc_v=netcdf.defVar(ncid,'zc','double',[one_d K_d]);


% meshunion.cell
cell_type_v=netcdf.defVar(ncid,'cell_type','NC_BYTE',one_d);
cell_Nv_v=netcdf.defVar(ncid,'cell_Nv','double',one_d);
cell_LAV_v=netcdf.defVar(ncid,'cell_LAV','double',one_d);
cell_vr_v=netcdf.defVar(ncid,'cell_vr','double',[cell_Nv_d one_d]);
cell_vs_v=netcdf.defVar(ncid,'cell_vs','double',[cell_Nv_d one_d]);
cell_vt_v=netcdf.defVar(ncid,'cell_vt','double',[cell_Nv_d one_d]);
cell_Nfv_v=netcdf.defVar(ncid,'cell_Nfv','double',[one_d cell_Nface_d]);
cell_FToV_v=netcdf.defVar(ncid,'cell_FToV','double',[four_d cell_Nface_d]);
cell_Nface_v=netcdf.defVar(ncid,'cell_Nface','double',one_d);
cell_faceType_v=netcdf.defVar(ncid,'cell_faceType','NC_BYTE',[one_d cell_Nface_d]);
cell_N_v=netcdf.defVar(ncid,'cell_N','double',one_d);
cell_Nz_v=netcdf.defVar(ncid,'cell_Nz','double',one_d);%chenzereng
cell_Np_v=netcdf.defVar(ncid,'cell_Np','double',one_d);
cell_Nph_v=netcdf.defVar(ncid,'cell_Nph','double',one_d);%chenzereng
cell_Npz_v=netcdf.defVar(ncid,'cell_Npz','double',one_d);%chenzereng
cell_V1d_v=netcdf.defVar(ncid,'cell_V1d','double',[Nzadd1_d Nzadd1_d]);%chenzereng
cell_r_v=netcdf.defVar(ncid,'cell_r','double',[Np_d one_d]);
cell_s_v=netcdf.defVar(ncid,'cell_s','double',[Np_d one_d]);
cell_t_v=netcdf.defVar(ncid,'cell_t','double',[Np_d one_d]);
cell_r1_v=netcdf.defVar(ncid,'cell_r1','double',[NfpBottom_d one_d]);%chenzereng
cell_s1_v=netcdf.defVar(ncid,'cell_s1','double',[NfpBottom_d one_d]);%chenzereng
cell_t1_v=netcdf.defVar(ncid,'cell_t1','double',[Nzadd1_d one_d]);%chenzereng
cell_Fmask_v=netcdf.defVar(ncid,'cell_Fmask','double',[Nfp_d cell_Nface_d]);
cell_Nfp_v=netcdf.defVar(ncid,'cell_Nfp','double',[cell_Nface_d one_d]);
cell_TNfp_v=netcdf.defVar(ncid,'cell_TNfp','double',one_d);
cell_V_v=netcdf.defVar(ncid,'cell_V','double',[Np_d Np_d]);
cell_Vh_v=netcdf.defVar(ncid,'cell_Vh','double',[NfpBottom_d NfpBottom_d]);%chenzereng
cell_Vint_v=netcdf.defVar(ncid,'cell_Vint','double',[Np_d Np_d]);%chenzereng
cell_VintU_v=netcdf.defVar(ncid,'cell_VintU','double',[Np_d Np_d]);%chenzereng
cell_VCV_v=netcdf.defVar(ncid,'cell_VCV','double',[NfpBottom_d Np_d]);%chenzereng
cell_Vq_v=netcdf.defVar(ncid,'cell_Vq','double',[cell_Nq_d Np_d]);
cell_M_v=netcdf.defVar(ncid,'cell_M','double',[Np_d Np_d]);
cell_invM_v=netcdf.defVar(ncid,'cell_invM','double',[Np_d Np_d]);
cell_Dr_v=netcdf.defVar(ncid,'cell_Dr','double',[Np_d Np_d]);
cell_Ds_v=netcdf.defVar(ncid,'cell_Ds','double',[Np_d Np_d]);
cell_Dt_v=netcdf.defVar(ncid,'cell_Dt','double',[Np_d Np_d]);
cell_Nq_v=netcdf.defVar(ncid,'cell_Nq','double',one_d);
cell_rq_v=netcdf.defVar(ncid,'cell_rq','double',[cell_Nq_d one_d]);
cell_sq_v=netcdf.defVar(ncid,'cell_sq','double',[cell_Nq_d one_d]);
cell_tq_v=netcdf.defVar(ncid,'cell_tq','double',[cell_Nq_d one_d]);
cell_wq_v=netcdf.defVar(ncid,'cell_wq','double',[cell_Nq_d one_d]);

% meshUnion.InnerEdge 18
%InnerEdge_r_v=netcdf.defVar(ncid,'InnerEdge_r','double',[Nfp_d one_d]);
InnerEdge_M_v=netcdf.defVar(ncid,'InnerEdge_M','double',[Nfp_d Nfp_d]);
InnerEdge_Ne_v=netcdf.defVar(ncid,'InnerEdge_Ne','double',one_d);
InnerEdge_Nfp_v=netcdf.defVar(ncid,'InnerEdge_Nfp','double',one_d);
InnerEdge_FToV_v=netcdf.defVar(ncid,'InnerEdge_FToV','double',[four_d Ne_inner_d]);
InnerEdge_FToE_v=netcdf.defVar(ncid,'InnerEdge_FToE','double',[two_d Ne_inner_d]);
InnerEdge_FToF_v=netcdf.defVar(ncid,'InnerEdge_FToF','double',[two_d Ne_inner_d]);
InnerEdge_FToM_v=netcdf.defVar(ncid,'InnerEdge_FToM','double',one_d);
InnerEdge_FToN1_v=netcdf.defVar(ncid,'InnerEdge_FToN1','double',[Nfp_d Ne_inner_d]);
InnerEdge_FToN2_v=netcdf.defVar(ncid,'InnerEdge_FToN2','double',[Nfp_d Ne_inner_d]);
InnerEdge_nx_v=netcdf.defVar(ncid,'InnerEdge_nx','double',[Nfp_d Ne_inner_d]);
InnerEdge_ny_v=netcdf.defVar(ncid,'InnerEdge_ny','double',[Nfp_d Ne_inner_d]);
InnerEdge_nz_v=netcdf.defVar(ncid,'InnerEdge_nz','double',[Nfp_d Ne_inner_d]);
InnerEdge_Js_v=netcdf.defVar(ncid,'InnerEdge_Js','double',[Nfp_d Ne_inner_d]);
InnerEdge_Jz_v=netcdf.defVar(ncid,'InnerEdge_Jz','double',[Nfp_d Ne_inner_d]);%chenzereng
InnerEdge_LAV_v=netcdf.defVar(ncid,'InnerEdge_LAV','double',[one_d Ne_inner_d]);
% add 3d vars
InnerEdge_V1d_v=netcdf.defVar(ncid,'InnerEdge_V1d','double',[Nfp2d_d Nfp2d_d]);%(N+1)**2 in limiter
InnerEdge_V2d_v=netcdf.defVar(ncid,'InnerEdge_V2d','double',[Nfp_d Nfp_d]);
InnerEdge_Nlayer_v=netcdf.defVar(ncid,'InnerEdge_Nlayer','double',one_d);

%boundaryedge 22
BoundaryEdge_ftype_v=netcdf.defVar(ncid,'BoundaryEdge_ftype','NC_BYTE',[Ne_boundary_d one_d]);
BoundaryEdge_xb_v=netcdf.defVar(ncid,'BoundaryEdge_xb','double',[Nfp_d Ne_boundary_d]);
BoundaryEdge_yb_v=netcdf.defVar(ncid,'BoundaryEdge_yb','double',[Nfp_d Ne_boundary_d]);
BoundaryEdge_zb_v=netcdf.defVar(ncid,'BoundaryEdge_zb','double',[Nfp_d Ne_boundary_d]);%chenzereng
%BoundaryEdge_r_v=netcdf.defVar(ncid,'BoundaryEdge_r','double',[Nfp_d one_d]);
BoundaryEdge_M_v=netcdf.defVar(ncid,'BoundaryEdge_M','double',[Nfp_d Nfp_d]);
BoundaryEdge_Ne_v=netcdf.defVar(ncid,'BoundaryEdge_Ne','double',one_d);
BoundaryEdge_Nfp_v=netcdf.defVar(ncid,'BoundaryEdge_Nfp','double',one_d);
BoundaryEdge_FToV_v=netcdf.defVar(ncid,'BoundaryEdge_FToV','double',[four_d Ne_boundary_d]);
BoundaryEdge_FToE_v=netcdf.defVar(ncid,'BoundaryEdge_FToE','double',[two_d Ne_boundary_d]);
BoundaryEdge_FToF_v=netcdf.defVar(ncid,'BoundaryEdge_FToF','double',[two_d Ne_boundary_d]);
BoundaryEdge_FToM_v=netcdf.defVar(ncid,'BoundaryEdge_FToM','double',[two_d Ne_boundary_d]);
BoundaryEdge_FToN1_v=netcdf.defVar(ncid,'BoundaryEdge_FToN1','double',[Nfp_d Ne_boundary_d]);
BoundaryEdge_FToN2_v=netcdf.defVar(ncid,'BoundaryEdge_FToN2','double',[Nfp_d Ne_boundary_d]);
BoundaryEdge_nx_v=netcdf.defVar(ncid,'BoundaryEdge_nx','double',[Nfp_d Ne_boundary_d]);
BoundaryEdge_ny_v=netcdf.defVar(ncid,'BoundaryEdge_ny','double',[Nfp_d Ne_boundary_d]);
BoundaryEdge_nz_v=netcdf.defVar(ncid,'BoundaryEdge_nz','double',[Nfp_d Ne_boundary_d]);
BoundaryEdge_Js_v=netcdf.defVar(ncid,'BoundaryEdge_Js','double',[Nfp_d Ne_boundary_d]);
BoundaryEdge_Jz_v=netcdf.defVar(ncid,'BoundaryEdge_Jz','double',[Nfp_d Ne_boundary_d]);%chenzereng
BoundaryEdge_LAV_v=netcdf.defVar(ncid,'BoundaryEdge_LAV','double',[one_d Ne_boundary_d]);
% add 3d vars
BoundaryEdge_V1d_v=netcdf.defVar(ncid,'BoundaryEdge_V1d','double',[Nfp2d_d Nfp2d_d]);%(N+1)**2 in limiter
BoundaryEdge_V2d_v=netcdf.defVar(ncid,'BoundaryEdge_V2d','double',[Nfp_d Nfp_d]);
BoundaryEdge_Nz_v=netcdf.defVar(ncid,'BoundaryEdge_Nz','double',one_d);


%bottomedge 14
BottomEdge_M_v=netcdf.defVar(ncid,'BottomEdge_M','double',[NfpBottom_d NfpBottom_d]);
BottomEdge_Ne_v=netcdf.defVar(ncid,'BottomEdge_Ne','double',one_d);
BottomEdge_Nfp_v=netcdf.defVar(ncid,'BottomEdge_Nfp','double',one_d);
BottomEdge_FToV_v=netcdf.defVar(ncid,'BottomEdge_FToV','double',[three_d K_d]);
BottomEdge_FToE_v=netcdf.defVar(ncid,'BottomEdge_FToE','double',[two_d Ne_bottom_d]);
BottomEdge_FToF_v=netcdf.defVar(ncid,'BottomEdge_FToF','double',[two_d Ne_bottom_d]);
BottomEdge_FToM_v=netcdf.defVar(ncid,'BottomEdge_FToM','double',one_d);
BottomEdge_FToN1_v=netcdf.defVar(ncid,'BottomEdge_FToN1','double',[NfpBottom_d Ne_bottom_d]);
BottomEdge_FToN2_v=netcdf.defVar(ncid,'BottomEdge_FToN2','double',[NfpBottom_d Ne_bottom_d]);
BottomEdge_nx_v=netcdf.defVar(ncid,'BottomEdge_nx','double',[NfpBottom_d Ne_bottom_d]);
BottomEdge_ny_v=netcdf.defVar(ncid,'BottomEdge_ny','double',[NfpBottom_d Ne_bottom_d]);
BottomEdge_nz_v=netcdf.defVar(ncid,'BottomEdge_nz','double',[NfpBottom_d Ne_bottom_d]);
BottomEdge_Js_v=netcdf.defVar(ncid,'BottomEdge_Js','double',[NfpBottom_d Ne_bottom_d]);
BottomEdge_LAV_v=netcdf.defVar(ncid,'BottomEdge_LAV','double',[one_d Ne_bottom_d]);

%bottomboundaryedge 15
BottomBoundaryEdge_ftype_v=netcdf.defVar(ncid,'BottomBoundaryEdge_ftype','NC_BYTE',[Ne_bottomboundary_d one_d]);
BottomBoundaryEdge_M_v=netcdf.defVar(ncid,'BottomBoundaryEdge_M','double',[NfpBottom_d NfpBottom_d]);
BottomBoundaryEdge_Ne_v=netcdf.defVar(ncid,'BottomBoundaryEdge_Ne','double',one_d);
BottomBoundaryEdge_Nfp_v=netcdf.defVar(ncid,'BottomBoundaryEdge_Nfp','double',one_d);
BottomBoundaryEdge_FToV_v=netcdf.defVar(ncid,'BottomBoundaryEdge_FToV','double',[three_d Ne_bottomboundary_d]);
BottomBoundaryEdge_FToE_v=netcdf.defVar(ncid,'BottomBoundaryEdge_FToE','double',[two_d Ne_bottomboundary_d]);
BottomBoundaryEdge_FToF_v=netcdf.defVar(ncid,'BottomBoundaryEdge_FToF','double',[two_d Ne_bottomboundary_d]);
BottomBoundaryEdge_FToM_v=netcdf.defVar(ncid,'BottomBoundaryEdge_FToM','double',one_d);
BottomBoundaryEdge_FToN1_v=netcdf.defVar(ncid,'BottomBoundaryEdge_FToN1','double',[NfpBottom_d Ne_bottomboundary_d]);
BottomBoundaryEdge_FToN2_v=netcdf.defVar(ncid,'BottomBoundaryEdge_FToN2','double',[NfpBottom_d Ne_bottomboundary_d]);
BottomBoundaryEdge_nx_v=netcdf.defVar(ncid,'BottomBoundaryEdge_nx','double',[NfpBottom_d Ne_bottomboundary_d]);
BottomBoundaryEdge_ny_v=netcdf.defVar(ncid,'BottomBoundaryEdge_ny','double',[NfpBottom_d Ne_bottomboundary_d]);
BottomBoundaryEdge_nz_v=netcdf.defVar(ncid,'BottomBoundaryEdge_nz','double',[NfpBottom_d Ne_bottomboundary_d]);
BottomBoundaryEdge_Js_v=netcdf.defVar(ncid,'BottomBoundaryEdge_Js','double',[NfpBottom_d Ne_bottomboundary_d]);
BottomBoundaryEdge_LAV_v=netcdf.defVar(ncid,'BottomBoundaryEdge_LAV','double',[one_d Ne_bottomboundary_d]);


%surfaceedge 15
SurfaceBoundaryEdge_ftype_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_ftype','NC_BYTE',[Ne_surface_d one_d]);
SurfaceBoundaryEdge_M_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_M','double',[NfpBottom_d NfpBottom_d]);
SurfaceBoundaryEdge_Ne_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_Ne','double',one_d);
SurfaceBoundaryEdge_Nfp_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_Nfp','double',one_d);
SurfaceBoundaryEdge_FToV_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_FToV','double',[three_d Ne_surface_d]);
SurfaceBoundaryEdge_FToE_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_FToE','double',[two_d Ne_surface_d]);
SurfaceBoundaryEdge_FToF_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_FToF','double',[two_d Ne_surface_d]);
SurfaceBoundaryEdge_FToM_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_FToM','double',one_d);
SurfaceBoundaryEdge_FToN1_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_FToN1','double',[NfpBottom_d Ne_surface_d]);
SurfaceBoundaryEdge_FToN2_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_FToN2','double',[NfpBottom_d Ne_surface_d]);
SurfaceBoundaryEdge_nx_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_nx','double',[NfpBottom_d Ne_surface_d]);
SurfaceBoundaryEdge_ny_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_ny','double',[NfpBottom_d Ne_surface_d]);
SurfaceBoundaryEdge_nz_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_nz','double',[NfpBottom_d Ne_surface_d]);
SurfaceBoundaryEdge_Js_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_Js','double',[NfpBottom_d Ne_surface_d]);
SurfaceBoundaryEdge_LAV_v=netcdf.defVar(ncid,'SurfaceBoundaryEdge_LAV','double',[one_d Ne_surface_d]);

%%%meshUnion.mesh2d%%%
type2d_v=netcdf.defVar(ncid,'type2d','NC_BYTE',one_d);
K2d_v=netcdf.defVar(ncid,'K2d','double',one_d);
Nv2d_v=netcdf.defVar(ncid,'Nv2d','double',one_d);
Ne_inner2d_v=netcdf.defVar(ncid,'Ne_inner2d','double',one_d);%chenzenreng
Ne_boundary2d_v=netcdf.defVar(ncid,'Ne_boundary2d','double',one_d);%chenzenreng
EToV2d_v=netcdf.defVar(ncid,'EToV2d','double',[cell_Nv2d_d K2d_d]);
EToR2d_v=netcdf.defVar(ncid,'EToR2d','double',[K2d_d one_d]);
vx2d_v=netcdf.defVar(ncid,'vx2d','double',[Nv2d_d one_d]);
vy2d_v=netcdf.defVar(ncid,'vy2d','double',[Nv2d_d one_d]);
vz2d_v=netcdf.defVar(ncid,'vz2d','double',[Nv2d_d one_d]);
ind2d_v=netcdf.defVar(ncid,'ind2d','double',one_d);
status_v=netcdf.defVar(ncid,'status','NC_BYTE',[one_d K2d_d]);
EToE2d_v=netcdf.defVar(ncid,'EToE2d','double',[cell_Nv2d_d K2d_d]);
EToF2d_v=netcdf.defVar(ncid,'EToF2d','double',[cell_Nv2d_d K2d_d]);
EToM2d_v=netcdf.defVar(ncid,'EToM2d','double',[cell_Nv2d_d K2d_d]);
x2d_v=netcdf.defVar(ncid,'x2d','double',[Np2d_d K2d_d]);
y2d_v=netcdf.defVar(ncid,'y2d','double',[Np2d_d K2d_d]);
z2d_v=netcdf.defVar(ncid,'z2d','double',[Np2d_d K2d_d]);
J2d_v=netcdf.defVar(ncid,'J2d','double',[Np2d_d K2d_d]);
rx2d_v=netcdf.defVar(ncid,'rx2d','double',[Np2d_d K2d_d]);
ry2d_v=netcdf.defVar(ncid,'ry2d','double',[Np2d_d K2d_d]);
rz2d_v=netcdf.defVar(ncid,'rz2d','double',[Np2d_d K2d_d]);
sx2d_v=netcdf.defVar(ncid,'sx2d','double',[Np2d_d K2d_d]);
sy2d_v=netcdf.defVar(ncid,'sy2d','double',[Np2d_d K2d_d]);
sz2d_v=netcdf.defVar(ncid,'sz2d','double',[Np2d_d K2d_d]);
tx2d_v=netcdf.defVar(ncid,'tx2d','double',[Np2d_d K2d_d]);
ty2d_v=netcdf.defVar(ncid,'ty2d','double',[Np2d_d K2d_d]);
tz2d_v=netcdf.defVar(ncid,'tz2d','double',[Np2d_d K2d_d]);
LAV2d_v=netcdf.defVar(ncid,'LAV2d','double',[one_d K2d_d]);
charLength2d_v=netcdf.defVar(ncid,'charLength2d','double',[one_d K2d_d]);
xc2d_v=netcdf.defVar(ncid,'xc2d','double',[one_d K2d_d]);
yc2d_v=netcdf.defVar(ncid,'yc2d','double',[one_d K2d_d]);
zc2d_v=netcdf.defVar(ncid,'zc2d','double',[one_d K2d_d]);

%2dcell
cell_type2d_v=netcdf.defVar(ncid,'cell_type2d','NC_BYTE',one_d);
cell_Nv2d_v=netcdf.defVar(ncid,'cell_Nv2d','double',one_d);
cell_LAV2d_v=netcdf.defVar(ncid,'cell_LAV2d','double',one_d);
cell_vr2d_v=netcdf.defVar(ncid,'cell_vr2d','double',[cell_Nv2d_d one_d]);
cell_vs2d_v=netcdf.defVar(ncid,'cell_vs2d','double',[cell_Nv2d_d one_d]);
cell_vt2d_v=netcdf.defVar(ncid,'cell_vt2d','double',[cell_Nv2d_d one_d]);
cell_Nfv2d_v=netcdf.defVar(ncid,'cell_Nfv2d','double',[one_d cell_Nv2d_d]);
cell_FToV2d_v=netcdf.defVar(ncid,'cell_FToV2d','double',[two_d cell_Nv2d_d]);
cell_Nface2d_v=netcdf.defVar(ncid,'cell_Nface2d','double',one_d);
cell_faceType2d_v=netcdf.defVar(ncid,'cell_faceType2d','NC_BYTE',[one_d cell_Nv2d_d]);
cell_N2d_v=netcdf.defVar(ncid,'cell_N2d','double',one_d);
cell_Np2d_v=netcdf.defVar(ncid,'cell_Np2d','double',one_d);
cell_r2d_v=netcdf.defVar(ncid,'cell_r2d','double',[Np2d_d one_d]);
cell_s2d_v=netcdf.defVar(ncid,'cell_s2d','double',[Np2d_d one_d]);
cell_t2d_v=netcdf.defVar(ncid,'cell_t2d','double',[Np2d_d one_d]);
cell_Fmask2d_v=netcdf.defVar(ncid,'cell_Fmask2d','double',[Nfp2d_d cell_Nv2d_d]);
cell_Nfp2d_v=netcdf.defVar(ncid,'cell_Nfp2d','double',[cell_Nv2d_d one_d]);
cell_TNfp2d_v=netcdf.defVar(ncid,'cell_TNfp2d','double',one_d);
cell_V2d_v=netcdf.defVar(ncid,'cell_V2d','double',[Np2d_d Np2d_d]);
cell_Vq2d_v=netcdf.defVar(ncid,'cell_Vq2d','double',[cell_Nq2d_d Np2d_d]);
cell_M2d_v=netcdf.defVar(ncid,'cell_M2d','double',[Np2d_d Np2d_d]);
cell_invM2d_v=netcdf.defVar(ncid,'cell_invM2d','double',[Np2d_d Np2d_d]);
cell_Dr2d_v=netcdf.defVar(ncid,'cell_Dr2d','double',[Np2d_d Np2d_d]);
cell_Ds2d_v=netcdf.defVar(ncid,'cell_Ds2d','double',[Np2d_d Np2d_d]);
cell_Dt2d_v=netcdf.defVar(ncid,'cell_Dt2d','double',[Np2d_d Np2d_d]);
cell_Nq2d_v=netcdf.defVar(ncid,'cell_Nq2d','double',one_d);
cell_rq2d_v=netcdf.defVar(ncid,'cell_rq2d','double',[cell_Nq2d_d one_d]);
cell_sq2d_v=netcdf.defVar(ncid,'cell_sq2d','double',[cell_Nq2d_d one_d]);
cell_tq2d_v=netcdf.defVar(ncid,'cell_tq2d','double',[cell_Nq2d_d one_d]);
cell_wq2d_v=netcdf.defVar(ncid,'cell_wq2d','double',[cell_Nq2d_d one_d]);

%InnerEdge2d.cell
InnerEdge_cell_type2d_v=netcdf.defVar(ncid,'InnerEdge_cell_type2d','NC_BYTE',one_d);
InnerEdge_cell_Nv2d_v=netcdf.defVar(ncid,'InnerEdge_cell_Nv2d','double',one_d);
InnerEdge_cell_LAV2d_v=netcdf.defVar(ncid,'InnerEdge_cell_LAV2d','double',one_d);
InnerEdge_cell_vr2d_v=netcdf.defVar(ncid,'InnerEdge_cell_vr2d','double',[two_d one_d]);
InnerEdge_cell_vs2d_v=netcdf.defVar(ncid,'InnerEdge_cell_vs2d','double',[two_d one_d]);
InnerEdge_cell_vt2d_v=netcdf.defVar(ncid,'InnerEdge_cell_vt2d','double',[two_d one_d]);
InnerEdge_cell_Nfv2d_v=netcdf.defVar(ncid,'InnerEdge_cell_Nfv2d','double',[two_d one_d]);
InnerEdge_cell_FToV2d_v=netcdf.defVar(ncid,'InnerEdge_cell_FToV2d','double',[one_d two_d]);
InnerEdge_cell_Nface2d_v=netcdf.defVar(ncid,'InnerEdge_cell_Nface2d','double',one_d);
InnerEdge_cell_faceType2d_v=netcdf.defVar(ncid,'InnerEdge_cell_faceType2d','NC_BYTE',[two_d one_d]);
InnerEdge_cell_N2d_v=netcdf.defVar(ncid,'InnerEdge_cell_N2d','double',one_d);
InnerEdge_cell_Np2d_v=netcdf.defVar(ncid,'InnerEdge_cell_Np2d','double',one_d);
InnerEdge_cell_r2d_v=netcdf.defVar(ncid,'InnerEdge_cell_r2d','double',[Nfp2d_d one_d]);
InnerEdge_cell_s2d_v=netcdf.defVar(ncid,'InnerEdge_cell_s2d','double',[Nfp2d_d one_d]);
InnerEdge_cell_t2d_v=netcdf.defVar(ncid,'InnerEdge_cell_t2d','double',[Nfp2d_d one_d]);
InnerEdge_cell_Fmask2d_v=netcdf.defVar(ncid,'InnerEdge_cell_Fmask2d','double',[one_d two_d]);
InnerEdge_cell_Nfp2d_v=netcdf.defVar(ncid,'InnerEdge_cell_Nfp2d','double',[two_d one_d]);
InnerEdge_cell_TNfp2d_v=netcdf.defVar(ncid,'InnerEdge_cell_TNfp2d','double',one_d);
InnerEdge_cell_V2d_v=netcdf.defVar(ncid,'InnerEdge_cell_V2d','double',[Nfp2d_d Nfp2d_d]);
InnerEdge_cell_Vq2d_v=netcdf.defVar(ncid,'InnerEdge_cell_Vq2d','double',[icell_Nq_d Nfp2d_d]);
InnerEdge_cell_M2d_v=netcdf.defVar(ncid,'InnerEdge_cell_M2d','double',[Nfp2d_d Nfp2d_d]);
InnerEdge_cell_invM2d_v=netcdf.defVar(ncid,'InnerEdge_cell_invM2d','double',[Nfp2d_d Nfp2d_d]);
InnerEdge_cell_Dr2d_v=netcdf.defVar(ncid,'InnerEdge_cell_Dr2d','double',[Nfp2d_d Nfp2d_d]);
InnerEdge_cell_Ds2d_v=netcdf.defVar(ncid,'InnerEdge_cell_Ds2d','double',[Nfp2d_d Nfp2d_d]);
InnerEdge_cell_Dt2d_v=netcdf.defVar(ncid,'InnerEdge_cell_Dt2d','double',[Nfp2d_d Nfp2d_d]);
InnerEdge_cell_Nq2d_v=netcdf.defVar(ncid,'InnerEdge_cell_Nq2d','double',one_d);
InnerEdge_cell_rq2d_v=netcdf.defVar(ncid,'InnerEdge_cell_rq2d','double',[icell_Nq_d one_d]);
InnerEdge_cell_sq2d_v=netcdf.defVar(ncid,'InnerEdge_cell_sq2d','double',[icell_Nq_d one_d]);
InnerEdge_cell_tq2d_v=netcdf.defVar(ncid,'InnerEdge_cell_tq2d','double',[icell_Nq_d one_d]);
InnerEdge_cell_wq2d_v=netcdf.defVar(ncid,'InnerEdge_cell_wq2d','double',[icell_Nq_d one_d]);

%InnerEdge
InnerEdge_r2d_v=netcdf.defVar(ncid,'InnerEdge_r2d','double',[Nfp2d_d one_d]);
InnerEdge_M2d_v=netcdf.defVar(ncid,'InnerEdge_M2d','double',[Nfp2d_d Nfp2d_d]);
InnerEdge_Ne2d_v=netcdf.defVar(ncid,'InnerEdge_Ne2d','double',one_d);
InnerEdge_Nfp2d_v=netcdf.defVar(ncid,'InnerEdge_Nfp2d','double',one_d);
InnerEdge_FToV2d_v=netcdf.defVar(ncid,'InnerEdge_FToV2d','double',[two_d Ne_inner2d_d]);
InnerEdge_FToE2d_v=netcdf.defVar(ncid,'InnerEdge_FToE2d','double',[two_d Ne_inner2d_d]);
InnerEdge_FToF2d_v=netcdf.defVar(ncid,'InnerEdge_FToF2d','double',[two_d Ne_inner2d_d]);
InnerEdge_FToM2d_v=netcdf.defVar(ncid,'InnerEdge_FToM2d','double',one_d);
InnerEdge_FToN12d_v=netcdf.defVar(ncid,'InnerEdge_FToN12d','double',[Nfp2d_d Ne_inner2d_d]);
InnerEdge_FToN22d_v=netcdf.defVar(ncid,'InnerEdge_FToN22d','double',[Nfp2d_d Ne_inner2d_d]);
InnerEdge_nx2d_v=netcdf.defVar(ncid,'InnerEdge_nx2d','double',[Nfp2d_d Ne_inner2d_d]);
InnerEdge_ny2d_v=netcdf.defVar(ncid,'InnerEdge_ny2d','double',[Nfp2d_d Ne_inner2d_d]);
InnerEdge_nz2d_v=netcdf.defVar(ncid,'InnerEdge_nz2d','double',[Nfp2d_d Ne_inner2d_d]);
InnerEdge_Js2d_v=netcdf.defVar(ncid,'InnerEdge_Js2d','double',[Nfp2d_d Ne_inner2d_d]);
InnerEdge_LAV2d_v=netcdf.defVar(ncid,'InnerEdge_LAV2d','double',[one_d Ne_inner2d_d]);
%BoundaryEdge
BoundaryEdge_ftype2d_v=netcdf.defVar(ncid,'BoundaryEdge_ftype2d','NC_BYTE',[Ne_boundary2d_d one_d]);
BoundaryEdge_xb2d_v=netcdf.defVar(ncid,'BoundaryEdge_xb2d','double',[Nfp2d_d Ne_boundary2d_d]);
BoundaryEdge_yb2d_v=netcdf.defVar(ncid,'BoundaryEdge_yb2d','double',[Nfp2d_d Ne_boundary2d_d]);
BoundaryEdge_r2d_v=netcdf.defVar(ncid,'BoundaryEdge_r2d','double',[Nfp2d_d one_d]);
BoundaryEdge_M2d_v=netcdf.defVar(ncid,'BoundaryEdge_M2d','double',[Nfp2d_d Nfp2d_d]);
BoundaryEdge_Ne2d_v=netcdf.defVar(ncid,'BoundaryEdge_Ne2d','double',one_d);
BoundaryEdge_Nfp2d_v=netcdf.defVar(ncid,'BoundaryEdge_Nfp2d','double',one_d);
BoundaryEdge_FToV2d_v=netcdf.defVar(ncid,'BoundaryEdge_FToV2d','double',[two_d Ne_boundary2d_d]);
BoundaryEdge_FToE2d_v=netcdf.defVar(ncid,'BoundaryEdge_FToE2d','double',[two_d Ne_boundary2d_d]);
BoundaryEdge_FToF2d_v=netcdf.defVar(ncid,'BoundaryEdge_FToF2d','double',[two_d Ne_boundary2d_d]);
BoundaryEdge_FToM2d_v=netcdf.defVar(ncid,'BoundaryEdge_FToM2d','double',[two_d Ne_boundary2d_d]);
BoundaryEdge_FToN12d_v=netcdf.defVar(ncid,'BoundaryEdge_FToN12d','double',[Nfp2d_d Ne_boundary2d_d]);
BoundaryEdge_FToN22d_v=netcdf.defVar(ncid,'BoundaryEdge_FToN22d','double',[Nfp2d_d Ne_boundary2d_d]);
BoundaryEdge_nx2d_v=netcdf.defVar(ncid,'BoundaryEdge_nx2d','double',[Nfp2d_d Ne_boundary2d_d]);
BoundaryEdge_ny2d_v=netcdf.defVar(ncid,'BoundaryEdge_ny2d','double',[Nfp2d_d Ne_boundary2d_d]);
BoundaryEdge_nz2d_v=netcdf.defVar(ncid,'BoundaryEdge_nz2d','double',[Nfp2d_d Ne_boundary2d_d]);
BoundaryEdge_Js2d_v=netcdf.defVar(ncid,'BoundaryEdge_Js2d','double',[Nfp2d_d Ne_boundary2d_d]);
BoundaryEdge_LAV2d_v=netcdf.defVar(ncid,'BoundaryEdge_LAV2d','double',[one_d Ne_boundary2d_d]);


netcdf.endDef(ncid);
%------------------------------------------------------------------------%
netcdf.putVar(ncid,type_v,double(Solver.meshUnion.type));
netcdf.putVar(ncid,K_v,Solver.meshUnion.K);
netcdf.putVar(ncid,Nv_v,Solver.meshUnion.Nv);
netcdf.putVar(ncid,Nlayer_v,Solver.meshUnion.Nz);%chenzereng
netcdf.putVar(ncid,N_v,Solver.meshUnion.cell.N);%chenzereng
netcdf.putVar(ncid,Nz_v,Solver.meshUnion.cell.Nz);%chenzereng

netcdf.putVar(ncid,Ne_inner_v,Solver.meshUnion.InnerEdge.Ne);%chenzereng
netcdf.putVar(ncid,Ne_boundary_v,Solver.meshUnion.BoundaryEdge.Ne);
netcdf.putVar(ncid,Ne_bottom_v,Solver.meshUnion.BottomEdge.Ne);
netcdf.putVar(ncid,Ne_bottomboundary_v,Solver.meshUnion.BottomBoundaryEdge.Ne);
netcdf.putVar(ncid,Ne_surface_v,Solver.meshUnion.SurfaceBoundaryEdge.Ne);
netcdf.putVar(ncid,Nfp_v,Solver.meshUnion.InnerEdge.Nfp);
netcdf.putVar(ncid,Np_v,Solver.meshUnion.cell.Np);
netcdf.putVar(ncid,NfpBottom_v,Solver.meshUnion.BottomEdge.Nfp);
netcdf.putVar(ncid,Ne_inner2d_v,Solver.meshUnion.mesh2d.InnerEdge.Ne);%chenzereng
netcdf.putVar(ncid,Ne_boundary2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.Ne);

netcdf.putVar(ncid,Nzadd1_v,1+Solver.meshUnion.cell.Nz);%chenzereng
netcdf.putVar(ncid,EToV_v,Solver.meshUnion.EToV);
%netcdf.putVar(ncid,EToR_v,Solver.meshUnion.EToR);
netcdf.putVar(ncid,vx_v,Solver.meshUnion.vx);
netcdf.putVar(ncid,vy_v,Solver.meshUnion.vy);
netcdf.putVar(ncid,vz_v,Solver.meshUnion.vz);
netcdf.putVar(ncid,ind_v,Solver.meshUnion.ind);

%netcdf.putVar(ncid,status_v,Solver.meshUnion.status);
netcdf.putVar(ncid,EToE_v,Solver.meshUnion.EToE);
netcdf.putVar(ncid,EToF_v,Solver.meshUnion.EToF);
netcdf.putVar(ncid,EToM_v,Solver.meshUnion.EToM);
netcdf.putVar(ncid,EToL_v,Solver.meshUnion.EToL);%chenzereng
netcdf.putVar(ncid,x_v,Solver.meshUnion.x);
netcdf.putVar(ncid,y_v,Solver.meshUnion.y);
netcdf.putVar(ncid,z_v,Solver.meshUnion.z);
netcdf.putVar(ncid,J_v,Solver.meshUnion.J);
netcdf.putVar(ncid,Jz_v,Solver.meshUnion.Jz);
netcdf.putVar(ncid,rx_v,Solver.meshUnion.rx);
netcdf.putVar(ncid,ry_v,Solver.meshUnion.ry);
netcdf.putVar(ncid,rz_v,Solver.meshUnion.rz);
netcdf.putVar(ncid,sx_v,Solver.meshUnion.sx);
netcdf.putVar(ncid,sy_v,Solver.meshUnion.sy);
netcdf.putVar(ncid,sz_v,Solver.meshUnion.sz);
netcdf.putVar(ncid,tx_v,Solver.meshUnion.tx);
netcdf.putVar(ncid,ty_v,Solver.meshUnion.ty);
netcdf.putVar(ncid,tz_v,Solver.meshUnion.tz);
netcdf.putVar(ncid,LAV_v,Solver.meshUnion.LAV);
%netcdf.putVar(ncid,charLength_v,Solver.meshUnion.charLength);
netcdf.putVar(ncid,xc_v,Solver.meshUnion.xc);
netcdf.putVar(ncid,yc_v,Solver.meshUnion.yc);
netcdf.putVar(ncid,zc_v,Solver.meshUnion.zc);

netcdf.putVar(ncid,cell_type_v,double(Solver.meshUnion.cell.type));
netcdf.putVar(ncid,cell_Nv_v,Solver.meshUnion.cell.Nv);
netcdf.putVar(ncid,cell_LAV_v,Solver.meshUnion.cell.LAV);
netcdf.putVar(ncid,cell_vr_v,Solver.meshUnion.cell.vr);
netcdf.putVar(ncid,cell_vs_v,Solver.meshUnion.cell.vs);
netcdf.putVar(ncid,cell_vt_v,Solver.meshUnion.cell.vt);
netcdf.putVar(ncid,cell_Nfv_v,Solver.meshUnion.cell.Nfv);
netcdf.putVar(ncid,cell_FToV_v,Solver.meshUnion.cell.FToV);
netcdf.putVar(ncid,cell_Nface_v,Solver.meshUnion.cell.Nface);
netcdf.putVar(ncid,cell_faceType_v,double(Solver.meshUnion.cell.faceType));
netcdf.putVar(ncid,cell_N_v,Solver.meshUnion.cell.N);
netcdf.putVar(ncid,cell_Nz_v,Solver.meshUnion.cell.Nz);%chenzereng
netcdf.putVar(ncid,cell_Np_v,Solver.meshUnion.cell.Np);
netcdf.putVar(ncid,cell_Nph_v,Solver.meshUnion.cell.Nph);%chenzereng
netcdf.putVar(ncid,cell_Npz_v,Solver.meshUnion.cell.Npz);%chenzereng
netcdf.putVar(ncid,cell_V1d_v,Solver.meshUnion.cell.V1d);%chenzereng
netcdf.putVar(ncid,cell_r_v,Solver.meshUnion.cell.r);
netcdf.putVar(ncid,cell_s_v,Solver.meshUnion.cell.s);
netcdf.putVar(ncid,cell_t_v,Solver.meshUnion.cell.t);
netcdf.putVar(ncid,cell_r1_v,Solver.meshUnion.cell.r1);%chenzereng
netcdf.putVar(ncid,cell_s1_v,Solver.meshUnion.cell.s1);%chenzereng
netcdf.putVar(ncid,cell_t1_v,Solver.meshUnion.cell.t1);%chenzereng
netcdf.putVar(ncid,cell_Fmask_v,Solver.meshUnion.cell.Fmask);
netcdf.putVar(ncid,cell_Nfp_v,Solver.meshUnion.cell.Nfp);
netcdf.putVar(ncid,cell_TNfp_v,Solver.meshUnion.cell.TNfp);
netcdf.putVar(ncid,cell_V_v,Solver.meshUnion.cell.V);
netcdf.putVar(ncid,cell_Vh_v,Solver.meshUnion.cell.Vh);%chenzereng
netcdf.putVar(ncid,cell_Vint_v,Solver.meshUnion.cell.Vint);%chenzereng
netcdf.putVar(ncid,cell_VintU_v,Solver.meshUnion.cell.VintU);%chenzereng
netcdf.putVar(ncid,cell_VCV_v,Solver.meshUnion.cell.VCV);%chenzereng
netcdf.putVar(ncid,cell_Vq_v,Solver.meshUnion.cell.Vq);
netcdf.putVar(ncid,cell_M_v,Solver.meshUnion.cell.M);
netcdf.putVar(ncid,cell_invM_v,Solver.meshUnion.cell.invM);
netcdf.putVar(ncid,cell_Dr_v,Solver.meshUnion.cell.Dr);
netcdf.putVar(ncid,cell_Ds_v,Solver.meshUnion.cell.Ds);
netcdf.putVar(ncid,cell_Dt_v,Solver.meshUnion.cell.Dt);
netcdf.putVar(ncid,cell_Nq_v,Solver.meshUnion.cell.Nq);
netcdf.putVar(ncid,cell_rq_v,Solver.meshUnion.cell.rq);
netcdf.putVar(ncid,cell_sq_v,Solver.meshUnion.cell.sq);
netcdf.putVar(ncid,cell_tq_v,Solver.meshUnion.cell.tq);
netcdf.putVar(ncid,cell_wq_v,Solver.meshUnion.cell.wq);

%netcdf.putVar(ncid,InnerEdge_r_v,Solver.meshUnion.InnerEdge.r);
netcdf.putVar(ncid,InnerEdge_M_v,Solver.meshUnion.InnerEdge.M);
netcdf.putVar(ncid,InnerEdge_Ne_v,Solver.meshUnion.InnerEdge.Ne);
netcdf.putVar(ncid,InnerEdge_Nlayer_v,Solver.meshUnion.InnerEdge.Nz);%chenzereng
netcdf.putVar(ncid,InnerEdge_Nfp_v,Solver.meshUnion.InnerEdge.Nfp);
netcdf.putVar(ncid,InnerEdge_FToV_v,Solver.meshUnion.InnerEdge.FToV);
netcdf.putVar(ncid,InnerEdge_FToE_v,Solver.meshUnion.InnerEdge.FToE);
netcdf.putVar(ncid,InnerEdge_FToF_v,Solver.meshUnion.InnerEdge.FToF);
netcdf.putVar(ncid,InnerEdge_FToM_v,Solver.meshUnion.InnerEdge.FToM);
netcdf.putVar(ncid,InnerEdge_FToN1_v,Solver.meshUnion.InnerEdge.FToN1);
netcdf.putVar(ncid,InnerEdge_FToN2_v,Solver.meshUnion.InnerEdge.FToN2);
netcdf.putVar(ncid,InnerEdge_nx_v,Solver.meshUnion.InnerEdge.nx);
netcdf.putVar(ncid,InnerEdge_ny_v,Solver.meshUnion.InnerEdge.ny);
netcdf.putVar(ncid,InnerEdge_nz_v,Solver.meshUnion.InnerEdge.nz);
netcdf.putVar(ncid,InnerEdge_Js_v,Solver.meshUnion.InnerEdge.Js);
netcdf.putVar(ncid,InnerEdge_Jz_v,Solver.meshUnion.InnerEdge.Jz);
netcdf.putVar(ncid,InnerEdge_LAV_v,Solver.meshUnion.InnerEdge.LAV);
netcdf.putVar(ncid,InnerEdge_V1d_v,Solver.meshUnion.InnerEdge.V1d);
netcdf.putVar(ncid,InnerEdge_V2d_v,Solver.meshUnion.InnerEdge.V2d);

netcdf.putVar(ncid,BoundaryEdge_ftype_v,double(Solver.meshUnion.BoundaryEdge.ftype));
netcdf.putVar(ncid,BoundaryEdge_xb_v,Solver.meshUnion.BoundaryEdge.xb);
netcdf.putVar(ncid,BoundaryEdge_yb_v,Solver.meshUnion.BoundaryEdge.yb);
netcdf.putVar(ncid,BoundaryEdge_zb_v,Solver.meshUnion.BoundaryEdge.zb);
netcdf.putVar(ncid,BoundaryEdge_M_v,Solver.meshUnion.BoundaryEdge.M);
netcdf.putVar(ncid,BoundaryEdge_Ne_v,Solver.meshUnion.BoundaryEdge.Ne);
netcdf.putVar(ncid,BoundaryEdge_Nz_v,Solver.meshUnion.BoundaryEdge.Nz);%chenzereng
netcdf.putVar(ncid,BoundaryEdge_Nfp_v,Solver.meshUnion.BoundaryEdge.Nfp);
netcdf.putVar(ncid,BoundaryEdge_FToV_v,Solver.meshUnion.BoundaryEdge.FToV);
netcdf.putVar(ncid,BoundaryEdge_FToE_v,Solver.meshUnion.BoundaryEdge.FToE);
netcdf.putVar(ncid,BoundaryEdge_FToF_v,Solver.meshUnion.BoundaryEdge.FToF);
netcdf.putVar(ncid,BoundaryEdge_FToM_v,Solver.meshUnion.BoundaryEdge.FToM);
netcdf.putVar(ncid,BoundaryEdge_FToN1_v,Solver.meshUnion.BoundaryEdge.FToN1);
netcdf.putVar(ncid,BoundaryEdge_FToN2_v,Solver.meshUnion.BoundaryEdge.FToN2);
netcdf.putVar(ncid,BoundaryEdge_nx_v,Solver.meshUnion.BoundaryEdge.nx);
netcdf.putVar(ncid,BoundaryEdge_ny_v,Solver.meshUnion.BoundaryEdge.ny);
netcdf.putVar(ncid,BoundaryEdge_nz_v,Solver.meshUnion.BoundaryEdge.nz);
netcdf.putVar(ncid,BoundaryEdge_Js_v,Solver.meshUnion.BoundaryEdge.Js);
netcdf.putVar(ncid,BoundaryEdge_Jz_v,Solver.meshUnion.BoundaryEdge.Jz);
netcdf.putVar(ncid,BoundaryEdge_LAV_v,Solver.meshUnion.BoundaryEdge.LAV);
netcdf.putVar(ncid,BoundaryEdge_V1d_v,Solver.meshUnion.BoundaryEdge.V1d);
netcdf.putVar(ncid,BoundaryEdge_V2d_v,Solver.meshUnion.BoundaryEdge.V2d);

netcdf.putVar(ncid,BottomEdge_M_v,Solver.meshUnion.BottomEdge.M);
netcdf.putVar(ncid,BottomEdge_Ne_v,Solver.meshUnion.BottomEdge.Ne);
netcdf.putVar(ncid,BottomEdge_Nfp_v,Solver.meshUnion.BottomEdge.Nfp);
netcdf.putVar(ncid,BottomEdge_FToV_v,Solver.meshUnion.BottomEdge.FToV);
netcdf.putVar(ncid,BottomEdge_FToE_v,Solver.meshUnion.BottomEdge.FToE);
netcdf.putVar(ncid,BottomEdge_FToF_v,Solver.meshUnion.BottomEdge.FToF);
netcdf.putVar(ncid,BottomEdge_FToM_v,Solver.meshUnion.BottomEdge.FToM);
netcdf.putVar(ncid,BottomEdge_FToN1_v,Solver.meshUnion.BottomEdge.FToN1);
netcdf.putVar(ncid,BottomEdge_FToN2_v,Solver.meshUnion.BottomEdge.FToN2);
netcdf.putVar(ncid,BottomEdge_nx_v,Solver.meshUnion.BottomEdge.nx);
netcdf.putVar(ncid,BottomEdge_ny_v,Solver.meshUnion.BottomEdge.ny);
netcdf.putVar(ncid,BottomEdge_nz_v,Solver.meshUnion.BottomEdge.nz);
netcdf.putVar(ncid,BottomEdge_Js_v,Solver.meshUnion.BottomEdge.Js);
netcdf.putVar(ncid,BottomEdge_LAV_v,Solver.meshUnion.BottomEdge.LAV);

netcdf.putVar(ncid,BottomBoundaryEdge_ftype_v,double(Solver.meshUnion.BottomBoundaryEdge.ftype));
netcdf.putVar(ncid,BottomBoundaryEdge_M_v,Solver.meshUnion.BottomBoundaryEdge.M);
netcdf.putVar(ncid,BottomBoundaryEdge_Ne_v,Solver.meshUnion.BottomBoundaryEdge.Ne);
netcdf.putVar(ncid,BottomBoundaryEdge_Nfp_v,Solver.meshUnion.BottomBoundaryEdge.Nfp);
netcdf.putVar(ncid,BottomBoundaryEdge_FToV_v,Solver.meshUnion.BottomBoundaryEdge.FToV);
netcdf.putVar(ncid,BottomBoundaryEdge_FToE_v,Solver.meshUnion.BottomBoundaryEdge.FToE);
netcdf.putVar(ncid,BottomBoundaryEdge_FToF_v,Solver.meshUnion.BottomBoundaryEdge.FToF);
netcdf.putVar(ncid,BottomBoundaryEdge_FToM_v,Solver.meshUnion.BottomBoundaryEdge.FToM);
netcdf.putVar(ncid,BottomBoundaryEdge_FToN1_v,Solver.meshUnion.BottomBoundaryEdge.FToN1);
netcdf.putVar(ncid,BottomBoundaryEdge_FToN2_v,Solver.meshUnion.BottomBoundaryEdge.FToN2);
netcdf.putVar(ncid,BottomBoundaryEdge_nx_v,Solver.meshUnion.BottomBoundaryEdge.nx);
netcdf.putVar(ncid,BottomBoundaryEdge_ny_v,Solver.meshUnion.BottomBoundaryEdge.ny);
netcdf.putVar(ncid,BottomBoundaryEdge_nz_v,Solver.meshUnion.BottomBoundaryEdge.nz);
netcdf.putVar(ncid,BottomBoundaryEdge_Js_v,Solver.meshUnion.BottomBoundaryEdge.Js);
netcdf.putVar(ncid,BottomBoundaryEdge_LAV_v,Solver.meshUnion.BottomBoundaryEdge.LAV);

netcdf.putVar(ncid,SurfaceBoundaryEdge_ftype_v,double(Solver.meshUnion.SurfaceBoundaryEdge.ftype));
netcdf.putVar(ncid,SurfaceBoundaryEdge_M_v,Solver.meshUnion.SurfaceBoundaryEdge.M);
netcdf.putVar(ncid,SurfaceBoundaryEdge_Ne_v,Solver.meshUnion.SurfaceBoundaryEdge.Ne);
netcdf.putVar(ncid,SurfaceBoundaryEdge_Nfp_v,Solver.meshUnion.SurfaceBoundaryEdge.Nfp);
netcdf.putVar(ncid,SurfaceBoundaryEdge_FToV_v,Solver.meshUnion.SurfaceBoundaryEdge.FToV);
netcdf.putVar(ncid,SurfaceBoundaryEdge_FToE_v,Solver.meshUnion.SurfaceBoundaryEdge.FToE);
netcdf.putVar(ncid,SurfaceBoundaryEdge_FToF_v,Solver.meshUnion.SurfaceBoundaryEdge.FToF);
netcdf.putVar(ncid,SurfaceBoundaryEdge_FToM_v,Solver.meshUnion.SurfaceBoundaryEdge.FToM);
netcdf.putVar(ncid,SurfaceBoundaryEdge_FToN1_v,Solver.meshUnion.SurfaceBoundaryEdge.FToN1);
netcdf.putVar(ncid,SurfaceBoundaryEdge_FToN2_v,Solver.meshUnion.SurfaceBoundaryEdge.FToN2);
netcdf.putVar(ncid,SurfaceBoundaryEdge_nx_v,Solver.meshUnion.SurfaceBoundaryEdge.nx);
netcdf.putVar(ncid,SurfaceBoundaryEdge_ny_v,Solver.meshUnion.SurfaceBoundaryEdge.ny);
netcdf.putVar(ncid,SurfaceBoundaryEdge_nz_v,Solver.meshUnion.SurfaceBoundaryEdge.nz);
netcdf.putVar(ncid,SurfaceBoundaryEdge_Js_v,Solver.meshUnion.SurfaceBoundaryEdge.Js);
netcdf.putVar(ncid,SurfaceBoundaryEdge_LAV_v,Solver.meshUnion.SurfaceBoundaryEdge.LAV);

%%%!!2d!!%%%
netcdf.putVar(ncid,type2d_v,double(Solver.meshUnion.mesh2d.type));
netcdf.putVar(ncid,K2d_v,Solver.meshUnion.mesh2d.K);
netcdf.putVar(ncid,Nv2d_v,Solver.meshUnion.mesh2d.Nv);
netcdf.putVar(ncid,EToV2d_v,Solver.meshUnion.mesh2d.EToV);
netcdf.putVar(ncid,EToR2d_v,Solver.meshUnion.mesh2d.EToR);
netcdf.putVar(ncid,vx2d_v,Solver.meshUnion.mesh2d.vx);
netcdf.putVar(ncid,vy2d_v,Solver.meshUnion.mesh2d.vy);
netcdf.putVar(ncid,vz2d_v,Solver.meshUnion.mesh2d.vz);
netcdf.putVar(ncid,ind2d_v,Solver.meshUnion.mesh2d.ind);

netcdf.putVar(ncid,status_v,Solver.meshUnion.mesh2d.status);
netcdf.putVar(ncid,EToE2d_v,Solver.meshUnion.mesh2d.EToE);
netcdf.putVar(ncid,EToF2d_v,Solver.meshUnion.mesh2d.EToF);
netcdf.putVar(ncid,EToM2d_v,Solver.meshUnion.mesh2d.EToM);
netcdf.putVar(ncid,x2d_v,Solver.meshUnion.mesh2d.x);
netcdf.putVar(ncid,y2d_v,Solver.meshUnion.mesh2d.y);
netcdf.putVar(ncid,z2d_v,Solver.meshUnion.mesh2d.z);
netcdf.putVar(ncid,J2d_v,Solver.meshUnion.mesh2d.J);
netcdf.putVar(ncid,rx2d_v,Solver.meshUnion.mesh2d.rx);
netcdf.putVar(ncid,ry2d_v,Solver.meshUnion.mesh2d.ry);
netcdf.putVar(ncid,rz2d_v,Solver.meshUnion.mesh2d.rz);
netcdf.putVar(ncid,sx2d_v,Solver.meshUnion.mesh2d.sx);
netcdf.putVar(ncid,sy2d_v,Solver.meshUnion.mesh2d.sy);
netcdf.putVar(ncid,sz2d_v,Solver.meshUnion.mesh2d.sz);
netcdf.putVar(ncid,tx2d_v,Solver.meshUnion.mesh2d.tx);
netcdf.putVar(ncid,ty2d_v,Solver.meshUnion.mesh2d.ty);
netcdf.putVar(ncid,tz2d_v,Solver.meshUnion.mesh2d.tz);
netcdf.putVar(ncid,LAV2d_v,Solver.meshUnion.mesh2d.LAV);
netcdf.putVar(ncid,charLength2d_v,Solver.meshUnion.mesh2d.charLength);
netcdf.putVar(ncid,xc2d_v,Solver.meshUnion.mesh2d.xc);
netcdf.putVar(ncid,yc2d_v,Solver.meshUnion.mesh2d.yc);
netcdf.putVar(ncid,zc2d_v,Solver.meshUnion.mesh2d.zc);

netcdf.putVar(ncid,cell_type2d_v,double(Solver.meshUnion.mesh2d.cell.type));
netcdf.putVar(ncid,cell_Nv2d_v,Solver.meshUnion.mesh2d.cell.Nv);
netcdf.putVar(ncid,cell_LAV2d_v,Solver.meshUnion.mesh2d.cell.LAV);
netcdf.putVar(ncid,cell_vr2d_v,Solver.meshUnion.mesh2d.cell.vr);
netcdf.putVar(ncid,cell_vs2d_v,Solver.meshUnion.mesh2d.cell.vs);
netcdf.putVar(ncid,cell_vt2d_v,Solver.meshUnion.mesh2d.cell.vt);
netcdf.putVar(ncid,cell_Nfv2d_v,Solver.meshUnion.mesh2d.cell.Nfv);
netcdf.putVar(ncid,cell_FToV2d_v,Solver.meshUnion.mesh2d.cell.FToV);
netcdf.putVar(ncid,cell_Nface2d_v,Solver.meshUnion.mesh2d.cell.Nface);
netcdf.putVar(ncid,cell_faceType2d_v,double(Solver.meshUnion.mesh2d.cell.faceType));
netcdf.putVar(ncid,cell_N2d_v,Solver.meshUnion.mesh2d.cell.N);
netcdf.putVar(ncid,cell_Np2d_v,Solver.meshUnion.mesh2d.cell.Np);
netcdf.putVar(ncid,cell_r2d_v,Solver.meshUnion.mesh2d.cell.r);
netcdf.putVar(ncid,cell_s2d_v,Solver.meshUnion.mesh2d.cell.s);
netcdf.putVar(ncid,cell_t2d_v,Solver.meshUnion.mesh2d.cell.t);
netcdf.putVar(ncid,cell_Fmask2d_v,Solver.meshUnion.mesh2d.cell.Fmask);
netcdf.putVar(ncid,cell_Nfp2d_v,Solver.meshUnion.mesh2d.cell.Nfp);
netcdf.putVar(ncid,cell_TNfp2d_v,Solver.meshUnion.mesh2d.cell.TNfp);
netcdf.putVar(ncid,cell_V2d_v,Solver.meshUnion.mesh2d.cell.V);
netcdf.putVar(ncid,cell_Vq2d_v,Solver.meshUnion.mesh2d.cell.Vq);
netcdf.putVar(ncid,cell_M2d_v,Solver.meshUnion.mesh2d.cell.M);
netcdf.putVar(ncid,cell_invM2d_v,Solver.meshUnion.mesh2d.cell.invM);
netcdf.putVar(ncid,cell_Dr2d_v,Solver.meshUnion.mesh2d.cell.Dr);
netcdf.putVar(ncid,cell_Ds2d_v,Solver.meshUnion.mesh2d.cell.Ds);
netcdf.putVar(ncid,cell_Dt2d_v,Solver.meshUnion.mesh2d.cell.Dt);
netcdf.putVar(ncid,cell_Nq2d_v,Solver.meshUnion.mesh2d.cell.Nq);
netcdf.putVar(ncid,cell_rq2d_v,Solver.meshUnion.mesh2d.cell.rq);
netcdf.putVar(ncid,cell_sq2d_v,Solver.meshUnion.mesh2d.cell.sq);
netcdf.putVar(ncid,cell_tq2d_v,Solver.meshUnion.mesh2d.cell.tq);
netcdf.putVar(ncid,cell_wq2d_v,Solver.meshUnion.mesh2d.cell.wq);

netcdf.putVar(ncid,InnerEdge_cell_type2d_v,double(Solver.meshUnion.mesh2d.InnerEdge.cell.type));
netcdf.putVar(ncid,InnerEdge_cell_Nv2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.Nv);
netcdf.putVar(ncid,InnerEdge_cell_LAV2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.LAV);
netcdf.putVar(ncid,InnerEdge_cell_vr2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.vr);
netcdf.putVar(ncid,InnerEdge_cell_vs2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.vs);
netcdf.putVar(ncid,InnerEdge_cell_vt2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.vt);
netcdf.putVar(ncid,InnerEdge_cell_Nfv2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.Nfv);
netcdf.putVar(ncid,InnerEdge_cell_FToV2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.FToV);
netcdf.putVar(ncid,InnerEdge_cell_Nface2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.Nface);
netcdf.putVar(ncid,InnerEdge_cell_faceType2d_v,double(Solver.meshUnion.mesh2d.InnerEdge.cell.faceType));
netcdf.putVar(ncid,InnerEdge_cell_N2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.N);
netcdf.putVar(ncid,InnerEdge_cell_Np2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.Np);
netcdf.putVar(ncid,InnerEdge_cell_r2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.r);
netcdf.putVar(ncid,InnerEdge_cell_s2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.s);
netcdf.putVar(ncid,InnerEdge_cell_t2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.t);
netcdf.putVar(ncid,InnerEdge_cell_Fmask2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.Fmask);
netcdf.putVar(ncid,InnerEdge_cell_Nfp2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.Nfp);
netcdf.putVar(ncid,InnerEdge_cell_TNfp2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.TNfp);
netcdf.putVar(ncid,InnerEdge_cell_V2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.V);
netcdf.putVar(ncid,InnerEdge_cell_Vq2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.Vq);
netcdf.putVar(ncid,InnerEdge_cell_M2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.M);
netcdf.putVar(ncid,InnerEdge_cell_invM2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.invM);
netcdf.putVar(ncid,InnerEdge_cell_Dr2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.Dr);
netcdf.putVar(ncid,InnerEdge_cell_Ds2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.Ds);
netcdf.putVar(ncid,InnerEdge_cell_Dt2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.Dt);
netcdf.putVar(ncid,InnerEdge_cell_Nq2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.Nq);
netcdf.putVar(ncid,InnerEdge_cell_rq2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.rq);
netcdf.putVar(ncid,InnerEdge_cell_sq2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.sq);
netcdf.putVar(ncid,InnerEdge_cell_tq2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.tq);
netcdf.putVar(ncid,InnerEdge_cell_wq2d_v,Solver.meshUnion.mesh2d.InnerEdge.cell.wq);

netcdf.putVar(ncid,InnerEdge_r2d_v,Solver.meshUnion.mesh2d.InnerEdge.r);
netcdf.putVar(ncid,InnerEdge_M2d_v,Solver.meshUnion.mesh2d.InnerEdge.M);
netcdf.putVar(ncid,InnerEdge_Ne2d_v,Solver.meshUnion.mesh2d.InnerEdge.Ne);
netcdf.putVar(ncid,InnerEdge_Nfp2d_v,Solver.meshUnion.mesh2d.InnerEdge.Nfp);
netcdf.putVar(ncid,InnerEdge_FToV2d_v,Solver.meshUnion.mesh2d.InnerEdge.FToV);
netcdf.putVar(ncid,InnerEdge_FToE2d_v,Solver.meshUnion.mesh2d.InnerEdge.FToE);
netcdf.putVar(ncid,InnerEdge_FToF2d_v,Solver.meshUnion.mesh2d.InnerEdge.FToF);
netcdf.putVar(ncid,InnerEdge_FToM2d_v,Solver.meshUnion.mesh2d.InnerEdge.FToM);
netcdf.putVar(ncid,InnerEdge_FToN12d_v,Solver.meshUnion.mesh2d.InnerEdge.FToN1);
netcdf.putVar(ncid,InnerEdge_FToN22d_v,Solver.meshUnion.mesh2d.InnerEdge.FToN2);
netcdf.putVar(ncid,InnerEdge_nx2d_v,Solver.meshUnion.mesh2d.InnerEdge.nx);
netcdf.putVar(ncid,InnerEdge_ny2d_v,Solver.meshUnion.mesh2d.InnerEdge.ny);
netcdf.putVar(ncid,InnerEdge_nz2d_v,Solver.meshUnion.mesh2d.InnerEdge.nz);
netcdf.putVar(ncid,InnerEdge_Js2d_v,Solver.meshUnion.mesh2d.InnerEdge.Js);
netcdf.putVar(ncid,InnerEdge_LAV2d_v,Solver.meshUnion.mesh2d.InnerEdge.LAV);

netcdf.putVar(ncid,BoundaryEdge_ftype2d_v,double(Solver.meshUnion.mesh2d.BoundaryEdge.ftype));
netcdf.putVar(ncid,BoundaryEdge_xb2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.xb);
netcdf.putVar(ncid,BoundaryEdge_yb2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.yb);
netcdf.putVar(ncid,BoundaryEdge_r2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.r);
netcdf.putVar(ncid,BoundaryEdge_M2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.M);
netcdf.putVar(ncid,BoundaryEdge_Ne2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.Ne);
netcdf.putVar(ncid,BoundaryEdge_Nfp2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.Nfp);
netcdf.putVar(ncid,BoundaryEdge_FToV2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.FToV);
netcdf.putVar(ncid,BoundaryEdge_FToE2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.FToE);
netcdf.putVar(ncid,BoundaryEdge_FToF2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.FToF);
netcdf.putVar(ncid,BoundaryEdge_FToM2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.FToM);
netcdf.putVar(ncid,BoundaryEdge_FToN12d_v,Solver.meshUnion.mesh2d.BoundaryEdge.FToN1);
netcdf.putVar(ncid,BoundaryEdge_FToN22d_v,Solver.meshUnion.mesh2d.BoundaryEdge.FToN2);
netcdf.putVar(ncid,BoundaryEdge_nx2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.nx);
netcdf.putVar(ncid,BoundaryEdge_ny2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.ny);
netcdf.putVar(ncid,BoundaryEdge_nz2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.nz);
netcdf.putVar(ncid,BoundaryEdge_Js2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.Js);
netcdf.putVar(ncid,BoundaryEdge_LAV2d_v,Solver.meshUnion.mesh2d.BoundaryEdge.LAV);


netcdf.close(ncid);















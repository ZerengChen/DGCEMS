%DGCEMS MPI for creating eptr.txt & eind.txt
clear,clc;
SMSfile = 'xxx\fort.14';

%--------------------------------------------------------------
fideptr = fopen('xxx\eptr.txt','w');

fid2 = fopen(SMSfile,'r');
if( fid2 < 0 )
    msgID = [mfilename, ':inputFileNameError'];
    msgtext = ['The input file name: ', filename, ' is incorrect'];
    ME = MException(msgID, msgtext);
    throw(ME);
end
% READ FIRST LINE
fgetl(fid2);
% READ NODES AND ELEMENTS
temp = fscanf(fid2,'%d',2); Nv = temp(2); Ne = temp(1);
data = fscanf(fid2,'%d %f %f %f\n',[4,Nv]);
data2 = fscanf(fid2,'%d %d %d %d %d\n',[5,Ne]);
%--------------------------------------------------------------

    fprintf(fideptr,'%d\n', Nv);
    fprintf(fideptr,'%d\n', 0);
    for i = 1:Ne
        fprintf(fideptr,'%d\n',3*i);        
    end
fclose(fideptr);

fideind = fopen('xxx\eind.txt','w');
    for j = 1:Ne
        fprintf(fideind,'%d\n',data2(5*j-2));
        fprintf(fideind,'%d\n',data2(5*j-1));
        fprintf(fideind,'%d\n',data2(5*j));
    end
fclose(fideind);

fclose(fid2);

function [ output_args ] = refine( input_args )
%REFINE Summary of this function goes here
%   Detailed explanation goes here


end
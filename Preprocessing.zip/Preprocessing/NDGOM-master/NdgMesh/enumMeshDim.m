classdef enumMeshDim < int8
    enumeration
        One      (1)
        Two      (2)
        Three    (3)
    end
end


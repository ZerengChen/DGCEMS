classdef enumNonhydrostaticType < int8

    enumeration
        Hydrostatic   (1)
        Nonhydrostatic    (2)
    end
end


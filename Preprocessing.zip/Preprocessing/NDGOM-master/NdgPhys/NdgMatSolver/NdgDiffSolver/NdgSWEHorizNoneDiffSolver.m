classdef NdgSWEHorizNoneDiffSolver
    %NDGSWEHORIZNONEDIFFSOLVER �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
    end
    
    methods
        function obj =  NdgSWEHorizNoneDiffSolver(~)
            
        end
        
        function  matEvaluateDiffRHS(obj, ~, ~)
            %doing nothing
        end
        
        function matClearGlobalMemory(obj)
            %Doing nothing
        end
    end
    
end


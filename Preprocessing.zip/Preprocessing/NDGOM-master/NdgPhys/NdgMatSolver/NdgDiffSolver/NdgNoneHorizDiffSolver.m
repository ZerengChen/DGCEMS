classdef NdgNoneHorizDiffSolver
    %NDGNONEHORIZDIFFSOLVER �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
    end
    
    methods
        
        function obj = NdgNoneHorizDiffSolver( physClass )
            %Doing nothing
        end
        
        function matEvaluateDiffRHS(obj, ~, ~)
            %Doing nothing
        end
        
        function matClearGlobalMemory(obj)
            %Doing nothing
        end
        
    end
    
end


classdef NdghydrostaticSolver3d
    %NDGHYDROSTATICSOLVER3D �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
    end
    
    methods
        
        function obj = NdghydrostaticSolver3d(PhysClass)
            %Doing Nothing
        end
        
        function fphys = NdgConservativeNonhydrostaticUpdata(obj, physClass, fphys, fphys2d, deltatime)
            %Doing Nothing
        end
        
        function matClearGlobalMemory( obj )
            %Doing Nothing
        end
    end
    
end


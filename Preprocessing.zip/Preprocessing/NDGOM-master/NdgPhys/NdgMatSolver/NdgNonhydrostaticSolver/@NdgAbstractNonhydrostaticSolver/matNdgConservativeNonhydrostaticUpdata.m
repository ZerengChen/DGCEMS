function fphys = matNdgConservativeNonhydrostaticUpdata(obj, PhysClass, fphys)
% Realize the one dimensional non-hydrostatic model
end
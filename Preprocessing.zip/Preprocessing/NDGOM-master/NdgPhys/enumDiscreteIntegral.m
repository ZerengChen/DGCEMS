classdef enumDiscreteIntegral < int8
    
    enumeration
        GaussQuadrature (0)
        QuadratureFree (1)
    end
    
end

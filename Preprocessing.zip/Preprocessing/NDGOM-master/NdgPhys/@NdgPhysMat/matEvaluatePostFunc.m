%> @brief Evaluate the post function
%> The post-function 
function fphys = matEvaluatePostFunc( obj, fphys )
end
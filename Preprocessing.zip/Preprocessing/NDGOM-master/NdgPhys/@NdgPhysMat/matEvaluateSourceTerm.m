%> @brief Updating the RHS term with the source term
%> 
function matEvaluateSourceTerm( obj, fphys )
end% func
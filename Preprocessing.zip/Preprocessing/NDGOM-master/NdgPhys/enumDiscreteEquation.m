classdef enumDiscreteEquation < int8
    
    enumeration
        Weak    (0)
        Strong  (1)
    end
    
end


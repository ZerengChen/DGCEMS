classdef enumViscosity < int8
    
    enumeration
        None (0)
        LDG  (1)
        Central (2)
    end
end


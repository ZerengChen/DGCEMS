classdef enumTemproalInterval < int8
   
    enumeration
        Constant (1)
        DeltaTime (2)
        DeltaStep (3)
    end
    
end

